
from flask import Flask, render_template, request, jsonify
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api._errors import NoTranscriptFound, VideoUnavailable
from urllib.parse import urlparse, parse_qs
import logging

# Set up logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)

def get_video_id(url):
    """Extract video ID from YouTube URL using urllib."""
    try:
        parsed_url = urlparse(url)
        if 'youtube' in parsed_url.netloc:
            query = parse_qs(parsed_url.query)
            return query.get("v", [None])[0]
        elif 'youtu.be' in parsed_url.netloc:
            return parsed_url.path[1:]  # Extract ID from shortened URLs
        return None
    except Exception as e:
        logging.error(f"Error extracting video ID: {str(e)}")
        return None

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/get_transcript', methods=['POST'])
def get_transcript():
    url = request.json.get('url')  # Fetching from JSON instead of form
    logging.debug(f"Received URL: {url}")
    video_id = get_video_id(url)

    if not video_id:
        logging.error("Invalid YouTube URL")
        return render_template('error.html', error_message="Invalid YouTube URL"), 400

    try:
        logging.debug(f"Fetching transcripts for video ID: {video_id}")
        transcripts = YouTubeTranscriptApi.list_transcripts(video_id)
        transcript_data = {}
        available_languages = []

        # Detect available languages for the transcript
        for transcript in transcripts:

            # Detect and sort the languages
            language = transcript.language_code

            logging.debug(f"Processing transcript for language: {language}")
            available_languages.append(language)

            try:
                if transcript.is_translatable:
                    logging.debug(f"Translating transcript to {language}")
                    translated = transcript.translate(f'{language}')  # Translate to the detected language
                    transcript_data[language] = translated.fetch()
                else:
                    transcript_data[language] = transcript.fetch()
            except Exception as e:
                logging.error(f"Error fetching/translating transcript for language {language}: {str(e)}")
                transcript_data[language] = {'error': f"Could not fetch/translate: {str(e)}"}

        logging.debug(f"Available languages: {available_languages}")
        logging.debug(f"Transcript data: {transcript_data}")

        # Return available languages as part of the response
        return jsonify({'success': True, 'transcripts': transcript_data, 'available_languages': available_languages})

    except NoTranscriptFound:
        logging.error("No transcript available for this video.")
        return render_template('error.html', error_message="No transcript available for this video."), 404
    except VideoUnavailable:
        logging.error("Video is unavailable.")
        return render_template('error.html', error_message="Video is unavailable."), 404
    except Exception as e:
        logging.error(f"Unexpected error occurred: {str(e)}")
        return render_template('error.html', error_message=f"An unexpected error occurred: {str(e)}"), 500


if __name__ == '__main__':
    app.run(debug=True)
